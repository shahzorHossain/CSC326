from bottle import run, get, post, request, static_file, redirect, route, template

template_path = 'resources/views/'

@get('/')
def index():
	return template(template_path + 'index',
        google_id='123',
        user_first_name='first',
        user_last_name='last'
    )

run(host="0.0.0.0", port=80, debug=True)
