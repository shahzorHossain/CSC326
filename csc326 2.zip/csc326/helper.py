import crawler

# Function to get urls from the backend given a word 
def get_urls(word):
	
	sorted_urls = []
	ranked_doc_ids = {}
	
	# search word in the lexicon
	word_from_lexicon = crawler.lexicon.find_one({'word':word})
	
	# if word is not found in the lexicon, return empty list
	if word_from_lexicon == None:
		return sorted_urls
		
	else:
		# get the word_id corresponding to the word
		word_id = word_from_lexicon['word_id']
		
		# get doc_ids associated to this word
		entry_from_inverted_index = crawler.inverted_index.find_one({'word_id':word_id})
		doc_ids = entry_from_inverted_index['doc_ids']
		
		# get the ranks of each doc_id from the pagerank database
		for doc_id in doc_ids:
			entry_from_pagerank = crawler.pagerank.find_one({'doc_id':doc_id})
			ranked_doc_ids[doc_id] = entry_from_pagerank['rank']
		# sort them in descending order			
		sorted_doc_ids = sorted(ranked_doc_ids, key=ranked_doc_ids.__getitem__, reverse=True)
		
		# find the corresponding url string of every doc_id in the doc_index and add them to the list
		for doc_id in sorted_doc_ids:
			entry_from_doc_index = crawler.doc_index.find_one({'doc_id':doc_id})
			sorted_urls.append(entry_from_doc_index['url'])
			
		return sorted_urls