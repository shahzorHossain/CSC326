# To test crawler.py, include "http://0.0.0.0:80/test_start" in "server/urls.txt."
# (Note: Test_start page contains links to test_1 and test_2 pages.)

from bottle import run, get, post, request, static_file, response, redirect, route, template, error
import bottle
from beaker.middleware import SessionMiddleware
from oauth2client.client import OAuth2WebServerFlow
from oauth2client.client import flow_from_clientsecrets
# from googleapiclient.errors import HttpError
# from googleapiclient.discovery import build
import httplib2
import pymongo
from autocorrect import spell
from enchant.checker import SpellChecker

# Setting up the mongoDB
client = pymongo.MongoClient()
db = client.database
lexicon = db.lexicon
inverted_index = db.inverted_index
pagerank = db.pagerank
doc_index = db.doc_index

MAX_LINK_PER_PAGE = 5

# import os
# cwd = os.getcwd()

template_path = "resources/views/"  # where to load template from
# bottle.TEMPLATE_PATH.insert(0,"/Users/seungbum/Documents/Test/resources/views/")
SESSION_GID_KEY_NAME = "gid"
countAll = {}  # resets history of word counts
recent_search_list = {}

user_document = {}

session_opts = {
    "session.type": "file",
    "session.cookie_expires": 300,
    "session.data_dir": "./data",
    "session.auto": True}
app = SessionMiddleware(bottle.app(), session_opts)

# Helper functions for session management


def session_setter(key, value):
    s = bottle.request.environ.get("beaker.session")
    if key != None:
        s[str(key)] = value
        s.save()


def session_getter(key):
    s = bottle.request.environ.get("beaker.session")
    return s[str(key)] if str(key) in s else None


def user_document_getter(gid):
    global user_document
    if gid == None:
        return None
    return user_document[str(gid)] if (gid in user_document) else None


def user_document_setter(gid, data):
    global user_document
    if gid == None:
        return False
    if gid in user_document:
        if data:
            # New data
            user_document[gid] = data
        else:
            # Delete existing data
            del user_document[gid]
        return True
    else:
        if data:
            # New data
            user_document[gid] = data
            return True
        else:
            return False

    return False

# 404 error page


@error(404)
def error404(error):
    return template(template_path + "error_page")

# Searching a query invokes this


@get('/get_more_data')
def load_more_data():
    # Read body params for loading more data
    word_to_search = request.query.word

    page = int(request.query.page)
    first_link = page * MAX_LINK_PER_PAGE
    rank_list = []

    url_list = []

    # Search urls from the mongoDB using a keyword
    # word_id = lexicon.find_one({"word" : word_to_search})['word_id']
    # doc_ids = inverted_index.find_one({"word_id" : word_id})['doc_ids']
    # for doc_id in doc_ids:
    # try:
    # rank_list.append(pagerank.find_one({"doc_id" : doc_id})['rank'])
    # except:
    # pass


    # Multi-word searching ----------------------------
    word_ids = []
    doc_ids = []
    words = word_to_search.split()  # Parse input query
    for word in words:
        word_ids.append(lexicon.find_one({"word": word})['word_id'])
    for word_id in word_ids:
        doc_ids = doc_ids + (inverted_index.find_one({"word_id": word_id})['doc_ids'])
    non_repeated_doc_ids = set(doc_ids)
    for doc_id in non_repeated_doc_ids:
        try:
            rank_list.append(pagerank.find_one({"doc_id": doc_id})['rank'])
        except:
            pass

    #------------------------------

    sorted_doc_ids = [x for _, x in sorted(zip(rank_list, non_repeated_doc_ids), reverse=True)]

    #sorted_doc_ids = sorted(doc_ids, key=pagerank.find_one({"doc_id" : doc_ids})['rank'])
    #url_list = [doc_index.find_one({"doc_id" : doc_id})['url'] for doc_id in sorted_doc_ids]
    for doc_id in sorted_doc_ids:
        d = doc_index.find_one({"doc_id": doc_id})
        url_list.append(d['title'])     # Title for the link appended
        url_list.append(d['url'])       # URL for the link appended

    # Take MAX_LINK_PER_PAGE number of urls every time
    urls = url_list[first_link:first_link + (MAX_LINK_PER_PAGE * 2)]
    # urls = ["title1", "link1", "title2", "link2", ...] (a list of strings)

    # We can only send a STR (make into a string)
    string_url_list = ', '.join(item for item in urls)

    # If we have something to send
    if string_url_list:
        return string_url_list
    else:
        # If we run out of links
        return None

# Session test page


@route("/test")
def test():
    session_id = bottle.request.environ.get("HTTP_COOKIE")
    s = bottle.request.environ.get("beaker.session")
    # s["test"] = s.get("test",0) + 1
    # s["test"] = s.get("test", seesion_id)
    s["test"] = session_id
    s.save()
    # return "Test counter: %d" % s["test"]
    return "Test counter: %s, %s" % (session_id, s["test"])

# Test pages for lab1


@get("/test_start")
def test_page():
    return static_file("test_start.html", root="./resources/views")


@get("/test_1")
def test_page():
    return static_file("test_1.html", root="./resources/views")


@get("/test_2")
def test_page():
    return static_file("test_2.html", root="./resources/views")

# Loads static files


@get("/resources/<path:path>")
def load_resources(path):
    return static_file(path, root="./resources")


@get("/login")
def login_page():
    flow = flow_from_clientsecrets("client_secrets.json",
                                   scope="https://www.googleapis.com/auth/plus.me https://www.googleapis.com/auth/userinfo.email",
                                   # redirect_uri="http://0.0.0.0:80/redirect")
                                   redirect_uri="http://localhost:8080/redirect")

    uri = flow.step1_get_authorize_url()
    redirect(str(uri))


@get("/logout")
def logout():
    # Get current gid of the session
    current_gid = session_getter(SESSION_GID_KEY_NAME)

    # Using the gid, clear user data
    user_document_setter(current_gid, None)

    # Set value of current gid of the session to None
    session_setter(SESSION_GID_KEY_NAME, None)

    redirect('/')


@get("/redirect")
def redirect_page():
    code = request.query.code
    flow = OAuth2WebServerFlow(client_id="719952241018-047qndms91rhlar26vd4viotsakj0ujf.apps.googleusercontent.com",
                               client_secret="VE7lGox8M8dlhz5QmxUgQBxE",
                               scope="https://www.googleapis.com/auth/plus.me https://www.googleapis.com/auth/userinfo.email",
                               # redirect_uri="http://0.0.0.0:80/redirect")
                               redirect_uri="http://localhost:8080/redirect")

    credentials = flow.step2_exchange(code)
    token = credentials.id_token["sub"]

    http = httplib2.Http()
    http = credentials.authorize(http)

    users_service = build("oauth2", "v2", http=http)
    temp_data = users_service.userinfo().get().execute()
    user_document_setter(temp_data["id"], temp_data)

    # Connects gid to the current session
    session_setter(SESSION_GID_KEY_NAME, temp_data["id"])

    redirect('/')


@get("/page_test")
def index():
    return template(template_path + "index",
                    google_id="123",
                    user_first_name="first",
                    user_last_name="last")

# When the query is submitted, search_query() gets called


@get("/")
def search_query():
    #raw_query = request.forms.get("keywords")
    raw_query = request.query.keywords  # Input string stored in the variable "raw_query"
    query = raw_query.lower()           # Converts all into lowercase

    if query == "":                     # If there is no input, load the home page again
        current_gid = session_getter(SESSION_GID_KEY_NAME)
        return template(template_path + "newhome",
                        user_document=user_document_getter(current_gid)
                        )  # main page

    else:                           # If there is some input
        global countAll
        global recent_search_list
        word_dict = dict()
        word_list = []
        sorted_wordlist = []
        current_gid = session_getter(SESSION_GID_KEY_NAME)
        current_user_data = user_document_getter(current_gid)
        link_counter = 0
        page_number = 1

        # replaces ^ with ** in math expression
        if "^" in query:
            print("here")
            query = query.replace("^", "**")

        # Check if the query is a math expression
        try:
            if (isinstance(eval(query), int)) or (isinstance(eval(query), float)):
                math_result = eval(query)
        # If query cannot be evaluated using eval()
        except:
            math_result = None

        # If user's first time searching and logged in
        if (current_gid not in countAll) and current_user_data:
            countAll[current_gid] = {}

        # If recent search list is empty and logged in
        if (current_gid not in recent_search_list) and current_user_data:
            recent_search_list[current_gid] = []

        i = 0  # Used later as a rank counter
        split_string = query.split()  # Parse query
        for word in split_string:
            if word not in word_list:  # Filters already existing words (duplicates)
                word_list += [word]
            word_dict[word] = word_dict.get(word, 0) + 1
            if current_user_data:
                countAll[current_gid][word] = countAll[current_gid].get(word, 0) + 1
        if current_user_data:           # If logged in
            # Update history table for the user
            for key in countAll[current_gid].keys():
                sorted_wordlist = sorted(countAll[current_gid], key=countAll[current_gid].get, reverse=True)  # A list of top20 keys
            # Add query from the beginning of the list
            if query in recent_search_list[current_gid]:
                recent_search_list[current_gid].remove(query)
            recent_search_list[current_gid].insert(0, query)

        #word_to_search = split_string[0]
        word_to_search = query

        template_countAll = {}
        template_recent_search_list = []
        try:
            template_countAll = countAll[current_gid] if current_gid else None
            template_recent_search_list = recent_search_list[current_gid] if current_gid else None
        except Exception as e:
            template_countAll = None
            template_recent_search_list = None

        # Autocompletion - checks spelling error and suggests a word
        print "keywords: {}".format(raw_query)
        text = raw_query
        autoCorrectError = 0
        chkr = SpellChecker("en_US", text)
        for err in chkr:
            autoCorrectError = 1
            print "err.word is {}".format(err.word)
            correctWord = spell(err.word)
            print(correctWord)
            err.replace(correctWord)
        fullCorrectedSentence = chkr.get_text()
        print "overall : {}".format(fullCorrectedSentence)

        # Results_page for Lab3
    return template(template_path + "results_page",
                    word_to_search=word_to_search,
                    link_counter=link_counter,
                    page_number=page_number,
                    user_document=user_document_getter(current_gid),
                    loggedin=bool(current_user_data),
                    autoCorrectErrors=autoCorrectError,
                    fullCorrectedSentence=fullCorrectedSentence,
                    math_result=math_result
                    )

    # Query_page for Lab1 and Lab2
    # return template(template_path + "query_page",
    #        raw_query=raw_query,
    #        word_list=word_list,
    #        word_dict=word_dict,
    #        sorted_wordlist=sorted_wordlist,
    #        countAll=template_countAll,
    #        loggedin=bool(current_user_data),
    #        user_document=user_document_getter(current_gid),
    #        recent_search_list=template_recent_search_list
  #       )


# application = bottle.default_app()
# from paste import httpserver
# httpserver.serve(app, host='localhost', port=8080)
# run(app=app, host="localhost", port=8080, debug=True)
run(app=app, host="0.0.0.0", port=80, debug=True)
