# README #
Project for CSC326 Lab 2
To run the server, type "python frontend.py" from the root directory.

To test the crawler, go to server folder and type "python crawler.py" while the server is running.

IP Address of web server is 52.90.125.3

If you require ssh, use this command first,

$ chmod 400 BotoBot.pem

$ ssh -i BotoBot.pem ubuntu@52.90.125.3

Afterwards, install the modules beaker, googleapiclient, oauth2client if they are not present:

Finally, run $ sudo python frontend.py

Public DNS after deployment: ec2-52-90-125-3.compute-1.amazonaws.com

#-----------NEW-----------

To setup the backend and print PageRank scores, first run MongoDB instance by typing the command: $ mongod --smallfiles
then go to server folder and type "python run_backend_test.py" while the server is running.


#BENCHMARK SETUP

Benchmark is done using sysstat, dstat, and ab tools

Run the following commands while the server is running to perform benchmarking
(the first four commands display 20 reports in total, 1 every 2 seconds)

To obtain CPU utilization: sar -u 2 20
To obtain memory utilization: sar -r 2 20
To obtain disk I/O statistics: iostat -d 2 20
To obtain network statistics: dstat -n 2 20
To run ab tool: ab -n 1000 -c 1000 http://ec2-52-90-125-3.compute-1.amazonaws.com/?keywords=helloworld+foo+bar

Results obtained when running server at maximum performance are in benchmark_results.pdf

------------------------------------------------------------------------
Benchmark result compared to Lab2:

running command : $ ab -n 1000 -c 200  http://ec2-52-90-125-3.compute-1.amazonaws.com/?keywords=helloworld+foo+bar


Concurrency Level:      200
Time taken for tests:   1.175 seconds
Complete requests:      12
Failed requests:        0
Total transferred:      29256 bytes
HTML transferred:       26052 bytes
Requests per second:    10.21 [#/sec] (mean)
Time per request:       19589.333 [ms] (mean)
Time per request:       97.947 [ms] (mean, across all concurrent requests)
Transfer rate:          24.31 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:       50  147 208.9     53     653
Processing:   135  468 232.0    368     970
Waiting:      129  456 233.8    366     967
Total:        185  615 258.2    560    1023

Percentage of the requests served within a certain time (ms)
  50%    560
  66%    774
  75%    778
  80%    778
  90%   1017
  95%   1023
  98%   1023
  99%   1023

Average response time, number of connections and maximun number of requests per seconds would all decrease for this lab due to more I/O requests. Lab 2 required in built memory which was faster to access than using a database like MongoDB. MongoDB also consumed memory and disk I/O, which as a result, increased in this lab.

#--------------------------------------------------LAB 4--------------------------------------------

Deployment script is attached in the server folder
$ python deploy.py

Terminate script in the server folder
$ python terminate.py



