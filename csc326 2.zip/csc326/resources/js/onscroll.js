var MAX_LINK_PER_PAGE = 5;

window.onload = function (){
  
  // First page loading
  loadDoc(0);
  var pageloaded = 0;

  // Load next page when the view reaches above the bottom of the window
  var paginationHeight = document.body.offsetHeight - window.innerHeight;
  console.log(paginationHeight);
  console.log("offset", document.body.offsetHeight)
  console.log("inner", window.innerHeight)

    window.onscroll = function() {
       scrollHeight = this.scrollY;
       console.log("scroll", scrollHeight);
       console.log("paginationHeight", paginationHeight);

        // Every time it is scrolled down by certain pixels
        if (window.scrollHeight % paginationHeight == 0){
          var page = Math.floor(scrollHeight/paginationHeight);
          
          // Load only if the current page has not been loaded
          if (page > pageloaded) {
            loadDoc(page);
          };

          // Keep track of loaded pages
          pageloaded = page;
        };
    };
};

function loadDoc(page) {
    // XMLHttpRequest for loading part of the page
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
      if (this.readyState == 4 && this.status == 200) {
        // readyState 4 (DONE)
        // status 200 (OK)

        if (this.responseText == 0){
          // Do nothing if no more links available
        }
        else {
          // Separate the single input string
          var myObj = this.responseText.split(",");
          console.log(myObj);

          for (i = 0; i < (MAX_LINK_PER_PAGE*2); i=i+2){
            // Display only if the link is available
            if (myObj[i]){
              // On the first try, replace the div
              document.getElementById("load_page").innerHTML +=
              "<div class='link'><a href=" + myObj[i+1]+ ">" + myObj[i] + "</a><br>" + myObj[i+1] + "</div>";
              };
            }; // for loop
          }; // else

          // Add page number and a separator line for each page
          page_number = page + 1;
          document.getElementById("load_page").innerHTML += "Page "+page_number+"<hr>"

          //alert("new page loaded")
      }; // if statement
    }; // Callback function
    
    var url = "/get_more_data";
    var params = "word=" + word + "&page=" + page;
    console.log("page", page);
    
    xhttp.open("GET", url+"?"+params, true);
    xhttp.send(null);
};
