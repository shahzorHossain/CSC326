import boto.ec2 as ec2

def create_instance():

    key_pair = "AnotherThing"
    instance_type = "t1.micro"
    image_id= "ami-8caa1ce4"
    security_group_name = "AnotherSecurity"

    # making the connection

    # if we have the credentials file, uncomment the following chunk

    try:
        with open("config.csv", 'r') as file:

            file.seek(0)  # pointer points to the first line
            content = file.readlines()
    except Exception as exception:
        print exception
        return None

    user_info = content[1].split(',')
    access_id = user_info[0].strip()
    secret_access = user_info[1].strip()


    # otherwise we can manually configure the access_id and access_id_secret
    # access_id =  "xxxxxxxxxx"
    # secret_access = "xxxxxxxxxx"

    conn = ec2.connect_to_region(region_name='us-east-1', aws_access_key_id= access_id, aws_secret_access_key= secret_access)


    # creating the key pair
    try:
        key = ec2.connection.EC2Connection().create_key_pair(key_name=key_pair)
        key.save('~/Desktop')
    except Exception as exception:
        print ("Key pair exception: " , exception )


    # creating the security group
    try:
        security_group = conn.create_security_group(name=security_group_name,description="Authorize following protocols and ports for the security group")
        security_group.authorize("icmp",-1, -1, "0.0.0.0/0") #to ping the server
        security_group.authorize("tcp", 22, 22, "0.0.0.0/0") #to allow ssh
        security_group.authorize("tcp", 80, 80, "0.0.0.0/0") #to allow http
    except Exception as exception:
        print ("Security group exception: " , exception )

    # creating the instance
    instance_reservation = conn.run_instances(image_id=image_id,key_name=key_pair,security_groups=[security_group_name],instance_type= instance_type)
    

def check_IP_address():

    access_id =  "xxxxxxxxxx"
    secret_access = "xxxxxxxxxx"
    # for checking IP Address of running instances

    conn = ec2.connect_to_region(region_name='us-east-1', aws_access_key_id= access_id, aws_secret_access_key= secret_access)

    instance_list = conn.get_only_instances()

    for instance in instance_list:
        print (instance.ip_address)

def create_key_pair():
    key_pair = "BotoBot"
    try:
        key = ec2.connection.EC2Connection().create_key_pair(key_name=key_pair)
        key.save('~/Desktop')
    except Exception as exception:
        print ("Key pair exception: " , exception)


create_instance()