import crawler
import pprint

# code to delete old content in the database
crawler.inverted_index.drop()
crawler.doc_index.drop()
crawler.lexicon.drop()
crawler.pagerank.drop()

# initialize crawler given urls in txt file
c = crawler.crawler(None,'urls.txt')

# crawl and populate database
c.crawl(depth=1)	

# rank pages using PageRank
c.rank_pages()

# print every entry in the pagerank database
for i in crawler.pagerank.find():
	pprint.pprint(i)

