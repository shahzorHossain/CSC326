
import boto.ec2 as ec2


access_id =  "xxxxxxxxxx"
secret_access = "xxxxxxxxxx"
# for checking IP Address of running instances

try:
    with open("./config.csv", 'r') as file:

        file.seek(0)  # pointer points to the first line
        content = file.readlines()
except Exception as exception:
    print exception
    

user_info = content[1].split(',')
access_id = user_info[0].strip()
secret_access = user_info[1].strip()

conn = ec2.connect_to_region(region_name='us-east-1', aws_access_key_id= access_id, aws_secret_access_key= secret_access)

instance_list = conn.get_only_instances()

for instance in instance_list:
    instanceID = instance.id

# STOP an instance:


conn.stop_instances(instance_ids=[instanceID])

# TERMINATE an instance:
conn.terminate_instances(instance_ids=[instanceID])
