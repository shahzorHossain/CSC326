import paramiko

import os
import boto.ec2 as ec2


def create_instance():

    key_pair = "AnotherFailure"
    instance_type = "t1.micro"
    image_id = "ami-8caa1ce4"
    security_group_name = "AnySecurityFailure"

    # making the connection

    # if we have the credentials file, uncomment the following chunk

    try:
        with open("config.csv", 'r') as file:

            file.seek(0)  # pointer points to the first line
            content = file.readlines()
    except Exception as exception:
        print exception
        return None

    user_info = content[1].split(',')
    access_id = user_info[0].strip()
    secret_access = user_info[1].strip()


    # otherwise we can manually configure the access_id and access_id_secret
    # access_id =  "xxxxxxxxxx"
    # secret_access = "xxxxxxxxxx"

    conn = ec2.connect_to_region(region_name='us-east-1', aws_access_key_id=access_id, aws_secret_access_key=secret_access)


    # creating the key pair
    try:
        key = ec2.connection.EC2Connection().create_key_pair(key_name=key_pair)
        key.save('./')
    except Exception as exception:
        print ("Key pair exception: ", exception)


    # creating the security group
    try:
        security_group = conn.create_security_group(name=security_group_name, description="Authorize following protocols and ports for the security group")
        security_group.authorize("icmp", -1, -1, "0.0.0.0/0")  # to ping the server
        security_group.authorize("tcp", 22, 22, "0.0.0.0/0")  # to allow ssh
        security_group.authorize("tcp", 80, 80, "0.0.0.0/0")  # to allow http
    except Exception as exception:
        print ("Security group exception: ", exception)

    # creating the instance
    instance_reservation = conn.run_instances(image_id=image_id, key_name=key_pair, security_groups=[security_group_name], instance_type=instance_type)


def get_IP_address():

    access_id = "xxxxxxxxxx"
    secret_access = "xxxxxxxxxx"
    # for checking IP Address of running instances

    try:
        with open("config.csv", 'r') as file:

            file.seek(0)  # pointer points to the first line
            content = file.readlines()
    except Exception as exception:
        print exception
        return None

    user_info = content[1].split(',')
    access_id = user_info[0].strip()
    secret_access = user_info[1].strip()

    conn = ec2.connect_to_region(region_name='us-east-1', aws_access_key_id=access_id, aws_secret_access_key=secret_access)

    instance_list = conn.get_only_instances()

    print instance_list

    for instance in instance_list:
        if instance.ip_address:
            return instance.ip_address


def create_key_pair():
    key_pair = "AnyKeypair"
    try:
        key = ec2.connection.EC2Connection().create_key_pair(key_name=key_pair)
        key.save('~/Desktop')
    except Exception as exception:
        print ("Key pair exception: ", exception)


create_instance()

#---------------------------------------------------------------------------------------------------------------------------------------
ip_address = str(get_IP_address()).replace('.', '-')
print(ip_address)

os.system("scp -o StrictHostKeyChecking=no -i AnotherFailure.pem -r ../../csc326/ ubuntu@ec2-" + ip_address + ".compute-1.amazonaws.com:~");

k = paramiko.RSAKey.from_private_key_file("AnotherFailure.pem")  # must be in your current dir
c = paramiko.SSHClient()
c.set_missing_host_key_policy(paramiko.AutoAddPolicy())

hostname = "ec2-" + ip_address + ".compute-1.amazonaws.com"
# print hostname
# hostname = "ec2-54-173-148-58.compute-1.amazonaws.com"
c.connect(hostname=hostname, username="ubuntu", pkey=k)

commands = ["sudo apt-get -y update",
            "sudo apt-get -y install python-pip python-dev build-essential",
            "sudo pip install --upgrade pip",
            "sudo apt-get -y install python-numpy",
            "sudo apt-get -y install python-bs4",
            "sudo apt-get -y install python-bottle",
            "sudo apt-get -y install python-oauth2client",
            "sudo apt-get -y install python-enchant",
            "sudo pip install autocorrect",
            "sudo pip install pymongo",
            "sudo pip install beaker",
            "sudo apt-get -y install git",
            "sudo pip install boto",
            "git clone --recursive git://github.com/google/google-api-python-client.git",
            "sudo apt-key adv --keyserver hkp://keyserver.ubuntu.com:80 --recv 0C49F3730359A14518585931BC711F9BA15703C6",
            'echo "deb [ arch=amd64 ] http://repo.mongodb.org/apt/ubuntu precise/mongodb-org/3.4 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-3.4.list',
            "sudo apt-get install -y mongodb-org",
            "sudo mkdir -p /data/db/",
            "sudo chown -R $USER /data/db",
            "killall mongod",
            "sudo service mongod start",
            "sudo python /home/ubuntu/csc326/server/run_backend_test.py",
            "sudo python /home/ubuntu/csc326/frontend.py"

            ]  # these commands will exec in series


for command in commands:
    print "Executing {}".format(command)
    stdin, stdout, stderr = c.exec_command(command)  # this command is executed on the *remote* server
    print stdout.read()
    print("Errors")
    print stderr.read()

c.close()
